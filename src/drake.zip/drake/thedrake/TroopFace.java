package drake.thedrake;

/**
 * Tento typ určuje lícovou a rubovou stranu jednotky.
 */
public enum TroopFace {
    AVERS,REVERS
}
