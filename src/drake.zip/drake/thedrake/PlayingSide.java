package drake.thedrake;

/**
 * představuje barvu, za kterou hráč hraje
 */
public enum PlayingSide {
    ORANGE, BLUE
}
